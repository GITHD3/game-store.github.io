Welcome to Vice City. Welcome to the 1980s. From the decade of big hair,
excess and pastel suits comes a story of one man's rise to the top of the criminal pile.