Grand Theft Auto 3

Set within the fictional Liberty City (loosely based on New York City) , 
the story follows Claude, a silent protagonist who,after being betrayed and 
left for dead by his girlfriend during a robbery, embarks ona quest for revenge that 
leads him to become entangled in a world of crime, drugs,gang warfare, and corruption. 
The game is played from a third-person perspective and its world is navigated on foot or by vehicle