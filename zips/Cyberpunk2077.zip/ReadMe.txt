Cyberpunk 2077 is an open-world, action-adventure RPG set in the dark 
future of Night City — a dangerous megalopolis obsessed with power, glamor, 
and ceaseless body modification.