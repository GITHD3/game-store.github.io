Grand Theft Auto V is an action-adventure game played from either a third-person orfirst-person 
perspective. Players complete missions—linear scenarios with set objectives—to progress 
through the story. Outside of the missions, players may freely roam the open world.