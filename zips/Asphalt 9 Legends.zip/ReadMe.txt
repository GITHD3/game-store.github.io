Asphalt 9: Legends, 

Released in 2018 by Gameloft, is a racing game with a notable car lineup, 
including the "TouchDrive" autopilot mode and "shockwave nitro." Compared to Asphalt 8, 
the graphics are significantly improved. The game features 219 cars divided into classes (D, C, B, A, and S), 
with players starting from the Mitsubishi Lancer Evolution X (Class D) and progressing to the 
Bugatti Bolide (Class S). To unlock and enhance cars, blueprints are required, and customization 
is possible through the car editor.
Moreover, cars now consume fuel during races, depending on their star level.